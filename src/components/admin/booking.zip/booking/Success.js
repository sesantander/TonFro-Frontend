import React, { Component } from "react";

import { Button, } from "antd";
import ActionComponent from "../ActionComponent";
import InputComponent from "../InputComponent";
import BackComponent from "../BackComponent";
import notification from '../../../services/notification';
import { ToastContainer } from 'react-toastify';
import '../../../assets/css/newSelect.css';
import check from './check.png'; 

class Success extends Component {
redirecttobookings = () => {

window.location="/booking"
}
redirecttoaddbooking = () => {
window.location="/bookings/add"
}
render(){

    
      return (
        <>
          <section className="content-header">
            <ToastContainer />
  
            <div className="bg-light lter b-b wrapper-md clearfix">
              <div className="pull-left">
               
              </div>
              <div className="pull-rigth">
                <BackComponent back="/booking"></BackComponent>
              </div>
            </div>
          </section>
          <section className="content">
           
              <div className="box">
                <div className="box-header with-border">
                
                  <div className="pull-rigth"></div>
                </div>
  
                <div className="box-body"> 
                  
                     
                  
                   
                    
  
                    <div className="col-md-12">
                    <h3>Successful payment</h3>

                    <img src={check} width="500" height="500" />

                    <div className="col-md-12">
                      <Button type="primary"onClick={this.redirecttobookings}>
                        Back to Bookings
                      </Button>
                      &nbsp;
                      &nbsp;
                      &nbsp;
                      &nbsp;
                      &nbsp;
                      <Button type="primary" onClick={this.redirecttoaddbooking}>
                        Continue adding bookings
                      </Button>
                    </div>
                   
                      </div>
  
                     
                 
                      
               
                </div>
                
              </div>
           
          </section>
        </>
      );
      }
    
}

 
   
export default Success;
